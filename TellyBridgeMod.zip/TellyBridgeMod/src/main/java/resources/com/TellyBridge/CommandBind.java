package com.tellybridge;

import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;
import org.lwjgl.input.Keyboard;

public class CommandBind extends CommandBase {
    @Override
    public String getCommandName() {
        return "bind";
    }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "/bind <key>";
    }

    @Override
    public void processCommand(ICommandSender sender, String[] args) {
        if (args.length != 1) {
            sender.addChatMessage(new ChatComponentText("Kullanım: /bind <key>"));
            return;
        }

        try {
            int key = Keyboard.getKeyIndex(args[0].toUpperCase());
            if (key == Keyboard.KEY_NONE) {
                sender.addChatMessage(new ChatComponentText("Geçersiz tuş."));
                return;
            }
            TellyBridgeHandler.setKey(key);
            sender.addChatMessage(new ChatComponentText("Tuş başarıyla bağlandı: " + args[0].toUpperCase()));
        } catch (Exception e) {
            sender.addChatMessage(new ChatComponentText("Hata: " + e.getMessage()));
        }
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 0;
    }
}
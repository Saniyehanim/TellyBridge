package com.tellybridge;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;

@Mod(modid = "tellybridge", name = "Telly Bridge", version = "1.0")
public class TellyBridgeMod {

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        // Handler kayıt
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(new TellyBridgeHandler());
    }

    @Mod.EventHandler
    public void onServerStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new CommandBind());
    }
}
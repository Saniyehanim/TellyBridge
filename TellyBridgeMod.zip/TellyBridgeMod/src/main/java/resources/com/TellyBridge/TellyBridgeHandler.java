package com.tellybridge;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import org.lwjgl.input.Keyboard;

public class TellyBridgeHandler {
    private static Minecraft mc = Minecraft.getMinecraft();
    private static boolean enabled = false;
    private static int keyCode = Keyboard.KEY_G; // Varsayılan G tuşu

    public static void setKey(int key) {
        keyCode = key;
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (Keyboard.isKeyDown(keyCode)) {
            enabled = !enabled;
            mc.thePlayer.addChatMessage(
                new net.minecraft.util.ChatComponentText("[TellyBridge] " + (enabled ? "Enabled" : "Disabled"))
            );
        }

        if (enabled && mc.thePlayer != null && mc.theWorld != null) {
            if (mc.thePlayer.onGround) {
                mc.thePlayer.jump();
            }
            mc.playerController.onPlayerRightClick(
                mc.thePlayer, mc.theWorld, mc.thePlayer.getHeldItem(),
                new net.minecraft.util.BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - 1, mc.thePlayer.posZ),
                net.minecraft.util.EnumFacing.UP,
                mc.thePlayer.getLookVec()
            );
        }
    }
}